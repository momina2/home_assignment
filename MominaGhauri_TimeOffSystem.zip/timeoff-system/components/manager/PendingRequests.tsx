



"use client";

import {
  useQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

import {
  getPendingRequests,
  approveRequest,
  rejectRequest,
} from "@/services/hcm";

import { TimeOffRequest } from "@/types/request";
import { Balance } from "@/types/balance";
import { getBalances } from "@/services/hcm";

export default function PendingRequests() {
  const queryClient = useQueryClient();

  const { data = [], isLoading } = useQuery<
    TimeOffRequest[]
  >({
    queryKey: ["pendingRequests"],
    queryFn: getPendingRequests,
  });

  const { data: balances = [] } = useQuery<
    Balance[]
  >({
    queryKey: ["balances"],
    queryFn: getBalances,
  });

  const approveMutation = useMutation({
    mutationFn: approveRequest,

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["pendingRequests"],
      });

      queryClient.invalidateQueries({
        queryKey: ["requests"],
      });

      queryClient.invalidateQueries({
        queryKey: ["balances"],
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: rejectRequest,

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["pendingRequests"],
      });

      queryClient.invalidateQueries({
        queryKey: ["requests"],
      });

      queryClient.invalidateQueries({
        queryKey: ["balances"],
      });
    },
  });

  if (isLoading) {
    return (
      <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-8">
        Loading requests...
      </div>
    );
  }

  return (
    <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-8 shadow-2xl">
      <h2 className="text-xl font-normal mb-6">
        Pending Requests
      </h2>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[900px] overflow-hidden rounded-xl">
          <thead>
            <tr>
              <th className="border border-slate-700 bg-slate-800 p-4">
                Location
              </th>

              <th className="border border-slate-700 bg-slate-800 p-4">
                Current Balance
              </th>

              <th className="border border-slate-700 bg-slate-800 p-4">
                Days
              </th>

              <th className="border border-slate-700 bg-slate-800 p-4">
                Status
              </th>

              <th className="border border-slate-700 bg-slate-800 p-4">
                Actions
              </th>
            </tr>
          </thead>

          <tbody>
            {data.length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className="border border-slate-700 text-center"
                >
                  <div className="py-14">
                    {/* <div className="text-5xl mb-4">
                    
                    </div>

                    <h3 className="text-xl font-semibold">
                      All Clear
                    </h3> */}

                    <p className="text-slate-400 mt-2">
                      There are no pending leave
                      requests.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              data.map((request) => (
                <tr
                  key={request.id}
                  className="hover:bg-slate-800/50 transition"
                >
                  <td className="border border-slate-700 p-4">
                    {request.locationId}
                  </td>

                  <td className="border border-slate-700 p-4">
                    {
                      balances.find(
                        (balance) =>
                          balance.employeeId ===
                          request.employeeId &&
                          balance.locationId ===
                          request.locationId
                      )?.balance ?? "-"
                    }
                  </td>



                  <td className="border border-slate-700 p-4">
                    {request.days}
                  </td>

                  <td className="border border-slate-700 p-4">
                    <span className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 px-3 py-1 rounded-full text-sm">
                      Pending
                    </span>
                  </td>

                  <td className="border border-slate-700 p-4">
                    <div className="flex gap-3">
                      <button
                        onClick={() =>
                          approveMutation.mutate(
                            request.id
                          )
                        }
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl font-medium transition"
                      >
                        ✓ Approve
                      </button>

                      <button
                        onClick={() =>
                          rejectMutation.mutate(
                            request.id
                          )
                        }
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl font-medium transition"
                      >
                        ✕ Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}