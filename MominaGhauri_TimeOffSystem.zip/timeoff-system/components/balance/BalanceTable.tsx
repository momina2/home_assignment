"use client";

import { useQuery } from "@tanstack/react-query";
import { getBalances } from "@/services/hcm";
import { Balance } from "@/types/balance";

export default function BalanceTable() {
  const {
    data,
    isLoading,
    error,
    dataUpdatedAt,
  } = useQuery({
    queryKey: ["balances"],
    queryFn: getBalances,

    refetchInterval: 30000,
    refetchOnWindowFocus: true,
  });

  if (isLoading) {
    return (
      <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
        Loading balances...
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-slate-900/80 backdrop-blur-xl border border-red-500 rounded-3xl p-6 shadow-2xl">
        Failed to load balances.
      </div>
    );
  }

  return (
    <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">
          Leave Balances
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Last synced:{" "}
          {new Date(
            dataUpdatedAt
          ).toLocaleTimeString()}
        </p>

        <span className="text-slate-400 text-sm">
          Employee EMP001
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {data?.map((item: Balance) => (
          <div
            key={item.locationId}
            className="
              bg-slate-800
              border
              border-slate-700
              rounded-2xl
              p-5
              hover:border-blue-500
              hover:shadow-lg
              transition-all
              duration-300
            "
          >
            <p className="text-slate-400 text-sm mb-2">
              {item.locationId === "LHR"
                ? "Lahore Office"
                : "Karachi Office"}
            </p>

            <h3 className="text-4xl font-bold mb-2">
              {item.balance}
            </h3>

            <div className="flex items-center justify-between">
              <span className="text-green-400 text-sm">
                Days Available
              </span>

              <span className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-xs">
                Active
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}