"use client";

import { useQuery } from "@tanstack/react-query";
import { getRequests } from "@/services/hcm";
import { TimeOffRequest } from "@/types/request";

export default function RequestHistory() {
    const { data = [] } = useQuery({
        queryKey: ["requests"],
        queryFn: getRequests,
    });

    return (
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
            <h2 className="text-2xl font-bold mb-5">
                Request History
            </h2>

            <table className="w-full overflow-hidden rounded-xl hover:bg-slate-800
transition-all rounded-xl overflow-hidden">
                <thead>
                    <tr>
                        <th className="border p-3">
                            Location
                        </th>

                        <th className="border p-3">
                            Days
                        </th>

                        <th className="border p-3">
                            Status
                        </th>
                    </tr>
                </thead>

                <tbody>
                    {data.map(
                        (request: TimeOffRequest) => (
                            <tr
                                key={request.id}
                                className="hover:bg-slate-800 transition"
                            >
                                <td className="border p-3">
                                    {request.locationId}
                                </td>

                                <td className="border p-3">
                                    {request.days}
                                </td>

                                <td className="border p-3">
                                    <span
                                        className={
                                            request.status ===
                                                "approved"
                                                ? "bg-green-500/20 text-green-400 border border-green-500/30 px-3 py-1 rounded-full text-sm"
                                                : request.status ===
                                                    "rejected"
                                                    ? "bg-red-500/20 text-red-400 border border-red-500/30 px-3 py-1 rounded-full text-sm"
                                                    : "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 px-3 py-1 rounded-full text-sm"
                                        }
                                    >
                                        {request.status}
                                    </span>
                                </td>
                            </tr>
                        )
                    )}
                </tbody>
            </table>
        </div>
    );
}