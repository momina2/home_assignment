"use client";

import { useState } from "react";
import {
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

import { Balance } from "@/types/balance";



import {
  submitRequest,
  getBalance,
  getRequests,
} from "@/services/hcm";
export default function RequestForm() {
  const [location, setLocation] =
    useState("LHR");

  const [days, setDays] = useState(1);

  const queryClient = useQueryClient();
  const [warning, setWarning] =
    useState("");

  const mutation = useMutation({
    mutationFn: submitRequest,

    onMutate: async (newRequest) => {
      await queryClient.cancelQueries({
        queryKey: ["balances"],
      });

      const previousBalances =
        queryClient.getQueryData<Balance[]>(
          ["balances"]
        );

      queryClient.setQueryData<Balance[]>(
        ["balances"],
        (old = []) =>
          old.map((item) =>
            item.locationId ===
              newRequest.locationId
              ? {
                ...item,
                balance:
                  item.balance -
                  newRequest.days,
              }
              : item
          )
      );

      return { previousBalances };
    },

    onError: (
      _error,
      _variables,
      context
    ) => {
      queryClient.setQueryData(
        ["balances"],
        context?.previousBalances
      );

      alert(
        "Request failed. Balance restored."
      );
    },

    // onSuccess: async () => {
    //   const latestBalance =
    //     await getBalance(
    //       "EMP001",
    //       location
    //     );



    //   if (latestBalance) {
    //     setWarning(
    //       "Latest balance was verified against HCM."
    //     );
    //   }

    //   if (latestBalance.balance < 0) {
    //     setWarning(
    //       "Balance data was reconciled with HCM. Please review your request."
    //     );
    //   }

    //   queryClient.invalidateQueries({
    //     queryKey: ["balances"],
    //   });

    //   queryClient.invalidateQueries({
    //     queryKey: ["requests"],
    //   });

    //   alert(
    //     "Request submitted successfully"
    //   );
    // },



    onSuccess: async () => {
      const requests =
        await getRequests();

      const requestExists =
        requests.some(
          (request: {
            employeeId: string;
            locationId: string;
            days: number;
            status: string;
          }) =>
            request.employeeId ===
            "EMP001" &&
            request.locationId ===
            location &&
            request.days === days &&
            request.status ===
            "pending"
        );

      if (!requestExists) {
        setWarning(
          "HCM reconciliation detected a mismatch. Your request may not have been processed."
        );
      }

      await getBalance(
        "EMP001",
        location
      );

      queryClient.invalidateQueries({
        queryKey: ["balances"],
      });

      queryClient.invalidateQueries({
        queryKey: ["requests"],
      });

      alert(
        "Request submitted successfully"
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries({
        queryKey: ["balances"],
      });

      queryClient.invalidateQueries({
        queryKey: ["requests"],
      });
    },
  });

  const handleSubmit = (
    e: React.FormEvent
  ) => {
    e.preventDefault();

    setWarning("");

    mutation.mutate({
      employeeId: "EMP001",
      locationId: location,
      days,
    });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="
      bg-slate-900/80
      backdrop-blur-xl
      border
      border-slate-700
      rounded-3xl
      p-6
      shadow-2xl
      "
    >
      <h2 className="text-2xl font-bold mb-6">
        Request Time Off
      </h2>
      {warning && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 text-yellow-300 rounded-xl p-3 mb-4">
          {warning}
        </div>
      )}

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-slate-300 text-sm">
            Location
          </label>

          <select
            value={location}
            onChange={(e) =>
              setLocation(e.target.value)
            }
            className="w-full"
          >
            <option value="LHR">
              Lahore
            </option>

            <option value="KHI">
              Karachi
            </option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-slate-300 text-sm">
            Number of Days
          </label>

          <input
            type="number"
            min={1}
            value={days}
            onChange={(e) =>
              setDays(
                Number(e.target.value)
              )
            }
            className="w-full"
          />
        </div>

        <button
          type="submit"
          disabled={mutation.isPending}
          className="
          w-full
          bg-blue-600
          hover:bg-blue-700
          text-white
          font-semibold
          py-3
          rounded-xl
          shadow-lg
          "
        >
          {mutation.isPending
            ? "Submitting..."
            : "Submit Request"}
        </button>
      </div>
    </form>
  );
}