export async function getBalances() {
  const response = await fetch("/api/hcm/balances");

  if (!response.ok) {
    throw new Error("Failed to fetch balances");
  }

  return response.json();
}

export async function submitRequest(data: {
  employeeId: string;
  locationId: string;
  days: number;
}) {
  const response = await fetch("/api/hcm/request", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.message);
  }

  return result;
}

export async function getRequests() {
  const response = await fetch("/api/hcm/requests");

  if (!response.ok) {
    throw new Error("Failed to fetch requests");
  }

  return response.json();
}


export async function getPendingRequests() {
  const response = await fetch(
    "/api/hcm/pending-requests"
  );

  if (!response.ok) {
    throw new Error("Failed to fetch requests");
  }

  return response.json();
}

export async function approveRequest(
  requestId: string
) {
  const response = await fetch(
    "/api/hcm/approve",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ requestId }),
    }
  );

  return response.json();
}

export async function rejectRequest(
  requestId: string
) {
  const response = await fetch(
    "/api/hcm/reject",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ requestId }),
    }
  );

  return response.json();
}

export async function getBalance(
  employeeId: string,
  locationId: string
) {
  const response = await fetch(
    `/api/hcm/balance?employeeId=${employeeId}&locationId=${locationId}`
  );

  if (!response.ok) {
    throw new Error("Failed to fetch balance");
  }

  return response.json();
}

export async function grantAnniversaryBonus() {
  const response = await fetch(
    "/api/hcm/anniversary-bonus",
    {
      method: "POST",
    }
  );

  if (!response.ok) {
    throw new Error(
      "Failed to grant anniversary bonus"
    );
  }

  return response.json();
}