


"use client";


import PendingRequests from "@/components/manager/PendingRequests";
import { TimeOffRequest } from "@/types/request";


import {
  useQuery,
  useMutation,
  useQueryClient,
} from "@tanstack/react-query";

import {
  getRequests,
  grantAnniversaryBonus,
} from "@/services/hcm";

export default function ManagerPage() {

  const queryClient = useQueryClient();

  const bonusMutation = useMutation({
    mutationFn: grantAnniversaryBonus,

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["balances"],
      });

      alert(
        "Anniversary bonus granted to all balances"
      );
    },
  });
  const { data: requests = [] } = useQuery<TimeOffRequest[]>({
    queryKey: ["requests"],
    queryFn: getRequests,
  });

  const pendingCount = requests.filter(
    (item) => item.status === "pending"
  ).length;

  const approvedCount = requests.filter(
    (item) => item.status === "approved"
  ).length;

  const rejectedCount = requests.filter(
    (item) => item.status === "rejected"
  ).length;

  return (
    <div className="min-h-screen w-full max-w-[1600px] mx-auto px-8 py-10">
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight">
          Manager Dashboard
        </h1>

        <p className="text-slate-400 mt-3 text-lg">
          Review and manage employee leave requests
        </p>
        <div className="mt-5">
          <button
            onClick={() =>
              bonusMutation.mutate()
            }
            className="
    bg-purple-600
    hover:bg-purple-700
    text-white
    px-5
    py-3
    rounded-xl
    font-medium
    transition
    "
          >
            Simulate Anniversary Bonus
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-8 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Pending Requests
          </p>

          <h2 className="text-5xl font-bold mt-2">
            {pendingCount}
          </h2>

          <span className="text-yellow-400 text-sm">
            Awaiting Decision
          </span>
        </div>

        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-8 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Approved Requests
          </p>

          <h2 className="text-5xl font-bold mt-2">
            {approvedCount}
          </h2>

          <span className="text-green-400 text-sm">
            Successfully Approved
          </span>
        </div>

        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-8 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Rejected Requests
          </p>

          <h2 className="text-5xl font-bold mt-2">
            {rejectedCount}
          </h2>

          <span className="text-red-400 text-sm">
            Rejected Requests
          </span>
        </div>
      </div>

      <PendingRequests />
    </div>
  );
}