

// import BalanceTable from "@/components/balance/BalanceTable";
// import RequestForm from "@/components/request/RequestForm";
// import RequestHistory from "@/components/request/RequestHistory";

// export default function EmployeePage() {
//   return (
//     <div className="min-h-screen max-w-7xl mx-auto p-8">

//       {/* Header */}
//       <div className="mb-10">
//         <h1 className="text-5xl font-bold tracking-tight">
//           Welcome Back
//         </h1>

//         <p className="text-slate-400 mt-3 text-lg">
//           Manage your leave balances and requests
//         </p>
//       </div>

//       {/* Stats Cards */}
//       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

//         <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
//           <p className="text-slate-400 text-sm">
//             Total Leave Balance
//           </p>

//           <h2 className="text-4xl font-bold mt-2">
//             16
//           </h2>

//           <span className="text-green-400 text-sm">
//             Available Days
//           </span>
//         </div>

//         <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
//           <p className="text-slate-400 text-sm">
//             Pending Requests
//           </p>

//           <h2 className="text-4xl font-bold mt-2">
//             2
//           </h2>

//           <span className="text-yellow-400 text-sm">
//             Awaiting Approval
//           </span>
//         </div>

//         <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
//           <p className="text-slate-400 text-sm">
//             Approved Requests
//           </p>

//           <h2 className="text-4xl font-bold mt-2">
//             5
//           </h2>

//           <span className="text-green-400 text-sm">
//             Successfully Approved
//           </span>
//         </div>

//       </div>

//       {/* Main Layout */}
//       <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

//         {/* Left Side */}
//         <div className="lg:col-span-3">
//           <RequestHistory />
//         </div>

//         {/* Right Side */}
//         <div className="lg:col-span-2 space-y-6">
//           <BalanceTable />
//           <RequestForm />
//         </div>

//       </div>

//     </div>
//   );
// }

"use client";

import { useQuery } from "@tanstack/react-query";

import {
  getBalances,
  getRequests,
} from "@/services/hcm";

import { Balance } from "@/types/balance";
import { TimeOffRequest } from "@/types/request";

import BalanceTable from "@/components/balance/BalanceTable";
import RequestForm from "@/components/request/RequestForm";
import RequestHistory from "@/components/request/RequestHistory";

export default function EmployeePage() {
  const { data: balances = [] } = useQuery<Balance[]>({
    queryKey: ["balances"],
    queryFn: getBalances,
  });

  const { data: requests = [] } = useQuery<TimeOffRequest[]>({
    queryKey: ["requests"],
    queryFn: getRequests,
  });

  const totalBalance = balances.reduce(
    (sum: number, item: Balance) => sum + item.balance,
    0
  );

  const pendingRequests = requests.filter(
    (item: TimeOffRequest) =>
      item.status === "pending"
  ).length;

  const approvedRequests = requests.filter(
    (item: TimeOffRequest) =>
      item.status === "approved"
  ).length;

  return (
    <div className="min-h-screen max-w-7xl mx-auto p-8">
      {/* Header */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight">
          Welcome Back 
        </h1>

        <p className="text-slate-400 mt-3 text-md">
          Manage your leave balances and requests
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Total Leave Balance
          </p>

          <h2 className="text-4xl font-bold mt-2">
            {totalBalance}
          </h2>

          <span className="text-green-400 text-sm">
            Available Days
          </span>
        </div>

        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Pending Requests
          </p>

          <h2 className="text-4xl font-bold mt-2">
            {pendingRequests}
          </h2>

          <span className="text-yellow-400 text-sm">
            Awaiting Approval
          </span>
        </div>

        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-6 shadow-2xl">
          <p className="text-slate-400 text-sm">
            Approved Requests
          </p>

          <h2 className="text-4xl font-bold mt-2">
            {approvedRequests}
          </h2>

          <span className="text-green-400 text-sm">
            Successfully Approved
          </span>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left Side */}
        <div className="lg:col-span-3">
          <RequestHistory />
        </div>

        {/* Right Side */}
        <div className="lg:col-span-2 space-y-6">
          <BalanceTable />
          <RequestForm />
        </div>
      </div>
    </div>
  );
}