import { NextResponse } from "next/server";
import { requests } from "@/mocks/data";

export async function GET() {
  const pendingRequests = requests.filter(
    (request) => request.status === "pending"
  );

  return NextResponse.json(pendingRequests);
}