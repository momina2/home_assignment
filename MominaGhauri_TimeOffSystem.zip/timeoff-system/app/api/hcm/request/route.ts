import { NextResponse } from "next/server";
import { balances, requests } from "@/mocks/data";

export async function POST(request: Request) {
  const body = await request.json();

  const balanceRow = balances.find(
    (item) =>
      item.employeeId === body.employeeId &&
      item.locationId === body.locationId,
  );

  if (!balanceRow) {
    return NextResponse.json(
      {
        message: "Invalid location",
      },
      {
        status: 400,
      },
    );
  }

  if (balanceRow.balance < body.days) {
    return NextResponse.json(
      {
        message: "Insufficient balance",
      },
      {
        status: 409,
      },
    );
  }

  const randomConflict = Math.random() < 0.05;

  if (randomConflict) {
    return NextResponse.json(
      {
        message: "HCM detected a concurrent balance update",
      },
      {
        status: 409,
      },
    );
  }

  const silentFailure = Math.random() < 0.03;

  if (silentFailure) {
    return NextResponse.json({
      success: true,
      message: "Request submitted successfully",
    });
  }

  balanceRow.balance -= body.days;

  requests.push({
    id: crypto.randomUUID(),
    employeeId: body.employeeId,
    locationId: body.locationId,
    days: body.days,
    status: "pending",
  });
  return NextResponse.json({
    success: true,
    message: "Request submitted successfully",
  });
}
