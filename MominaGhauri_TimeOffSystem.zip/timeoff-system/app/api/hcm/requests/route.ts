import { NextResponse } from "next/server";
import { balances, requests } from "@/mocks/data";

export async function GET() {
  return NextResponse.json(requests);
}
