import { NextResponse } from "next/server";
import { balances } from "@/mocks/data";

export async function GET() {
  return NextResponse.json(balances);
}