import { NextResponse } from "next/server";
import { requests } from "@/mocks/data";

export async function POST(request: Request) {
  const body = await request.json();

  const leaveRequest = requests.find(
    (item) => item.id === body.requestId
  );

  if (!leaveRequest) {
    return NextResponse.json(
      { message: "Request not found" },
      { status: 404 }
    );
  }

  leaveRequest.status = "approved";

  return NextResponse.json({
    success: true,
    message: "Request approved",
  });
}