import { NextResponse } from "next/server";
import { balances } from "@/mocks/data";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);

  const employeeId =
    searchParams.get("employeeId");

  const locationId =
    searchParams.get("locationId");

  const balance = balances.find(
    (item) =>
      item.employeeId === employeeId &&
      item.locationId === locationId
  );

  if (!balance) {
    return NextResponse.json(
      {
        message: "Balance not found",
      },
      {
        status: 404,
      }
    );
  }

  return NextResponse.json(balance);
}