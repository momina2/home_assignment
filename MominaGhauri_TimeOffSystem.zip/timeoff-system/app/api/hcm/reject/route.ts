import { NextResponse } from "next/server";
import { requests, balances } from "@/mocks/data";

export async function POST(request: Request) {
  const body = await request.json();

  console.log("BODY:", body);
  console.log("REQUESTS:", requests);

  const leaveRequest = requests.find((item) => item.id === body.requestId);
  if (!leaveRequest) {
    return NextResponse.json({ message: "Request not found" }, { status: 404 });
  }

  if (leaveRequest.status === "rejected") {
    return NextResponse.json({ message: "Already rejected" }, { status: 400 });
  }

  const balanceRow = balances.find(
    (item) =>
      item.employeeId === leaveRequest.employeeId &&
      item.locationId === leaveRequest.locationId,
  );

  if (balanceRow) {
    balanceRow.balance += leaveRequest.days;
  }

  leaveRequest.status = "rejected";

  return NextResponse.json({
    success: true,
    message: "Request rejected and balance restored",
  });
}
