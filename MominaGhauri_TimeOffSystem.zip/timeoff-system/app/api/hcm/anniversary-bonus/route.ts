import { NextResponse } from "next/server";
import { balances } from "@/mocks/data";

export async function POST() {
  balances.forEach((balance) => {
    balance.balance += 1;
    balance.updatedAt = Date.now();
  });

  return NextResponse.json({
    success: true,
    message: "Anniversary bonus granted",
  });
}