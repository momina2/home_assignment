// export default function Home() {
//   return (
//     <main className="min-h-screen flex flex-col items-center justify-center">
//       <h1 className="text-5xl font-bold">
//         ExampleHR Time-Off System
//       </h1>

//       <p className="mt-4 text-gray-500">
//         Frontend Assessment
//       </p>

//       <div className="flex gap-4 mt-10">
//         <a
//           href="/employee"
//           className="px-6 py-3 rounded-lg bg-blue-600 text-white"
//         >
//           Employee View
//         </a>

//         <a
//           href="/manager"
//           className="px-6 py-3 rounded-lg bg-green-600 text-white"
//         >
//           Manager View
//         </a>
//       </div>
//     </main>
//   );
// }


import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center max-w-3xl">
        <div className="mb-8">
          <span className="px-4 py-2 rounded-full border border-blue-500/30 bg-blue-500/10 text-blue-400 text-sm">
            Frontend Assessment
          </span>
        </div>

        <h1 className="text-6xl md:text-7xl font-extrabold tracking-tight mb-6">
          Time-Off
          <span className="text-blue-500"> System</span>
        </h1>

        <p className="text-slate-400 text-xl max-w-2xl mx-auto mb-10">
          Manage employee leave balances, submit time-off requests,
          and approve requests through a modern HR workflow.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link
            href="/employee"
            className="px-8 py-4 rounded-2xl bg-blue-600 hover:bg-blue-700 transition font-semibold shadow-xl"
          >
            Employee Dashboard
          </Link>

          <Link
            href="/manager"
            className="px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 transition font-semibold shadow-xl"
          >
            Manager Dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}