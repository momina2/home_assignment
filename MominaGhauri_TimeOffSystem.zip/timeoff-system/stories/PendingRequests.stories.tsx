import type { Meta, StoryObj } from "@storybook/nextjs";
import PendingRequests from "@/components/manager/PendingRequests";

const meta: Meta<typeof PendingRequests> = {
    title: "Manager/PendingRequests",
    component: PendingRequests,
};

export default meta;

type Story = StoryObj<typeof PendingRequests>;

export const Default: Story = {};

export const Empty: Story = {};

export const Loading: Story = {};