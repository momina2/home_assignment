import type { Meta, StoryObj } from "@storybook/nextjs";
import RequestHistory from "@/components/request/RequestHistory";

const meta: Meta<typeof RequestHistory> = {
  title: "Employee/RequestHistory",
  component: RequestHistory,
};

export default meta;

type Story = StoryObj<typeof RequestHistory>;

export const Default: Story = {};