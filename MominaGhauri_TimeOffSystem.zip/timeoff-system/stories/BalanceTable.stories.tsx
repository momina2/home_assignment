import type { Meta, StoryObj } from "@storybook/nextjs";
import BalanceTable from "@/components/balance/BalanceTable";

const meta: Meta<typeof BalanceTable> = {
    title: "Employee/BalanceTable",
    component: BalanceTable,
};

export default meta;

type Story = StoryObj<typeof BalanceTable>;

export const Default: Story = {};

export const RefreshedMidSession: Story = {};

export const StaleData: Story = {};