import type { Meta, StoryObj } from "@storybook/nextjs";
import RequestForm from "@/components/request/RequestForm";

const meta: Meta<typeof RequestForm> = {
    title: "Employee/RequestForm",
    component: RequestForm,
};

export default meta;

type Story = StoryObj<typeof RequestForm>;

export const Default: Story = {};

export const OptimisticPending: Story = {};

export const RolledBack: Story = {};

export const HCMSilentlyWrong: Story = {};