# Time-Off System



## Technical Requirement Document (TRD)

### Author

Momina Ghauri

### Project

Frontend Engineering Assessment – Time-Off System

---

# 1. Overview

The Time-Off System is a web-based leave management application built using Next.js, TypeScript, React Query, Tailwind CSS, Storybook, and Vitest.

The system allows employees to:

- View leave balances by location
- Submit time-off requests
- Track request history

Managers can:

- View pending requests
- Approve requests
- Reject requests
- Restore balances on rejection

The application demonstrates optimistic updates, cache synchronization, state management, component-driven development, and automated testing.

---

# 2. Goals

The primary goals of the application are:

- Provide a responsive leave management interface
- Simulate real-world HCM workflows
- Demonstrate optimistic UI updates
- Maintain synchronized application state
- Provide clear approval and rejection workflows
- Follow scalable frontend architecture principles
- Support component documentation and testing

---

# 3. Technology Stack

| Technology      | Purpose                  |
| --------------- | ------------------------ |
| Next.js         | Application Framework    |
| TypeScript      | Type Safety              |
| React Query     | Server State Management  |
| Tailwind CSS    | Styling                  |
| Storybook       | Component Documentation  |
| Vitest          | Unit & Component Testing |
| Playwright      | Browser Testing          |
| Mock API Routes | Backend Simulation       |

---

# 4. Architecture

```text
Employee Dashboard
│
├── BalanceTable
├── RequestForm
└── RequestHistory

Manager Dashboard
│
└── PendingRequests

Services Layer
│
└── services/hcm.ts

API Layer
│
├── /api/hcm/balances
├── /api/hcm/request
├── /api/hcm/requests
├── /api/hcm/pending-requests
├── /api/hcm/approve
└── /api/hcm/reject

Mock Data
│
└── mocks/data.ts
```

---

# 5. Data Models

## Balance

```ts
interface Balance {
  employeeId: string;
  locationId: string;
  balance: number;
  updatedAt: number;
}
```

## Time Off Request

```ts
interface TimeOffRequest {
  id: string;
  employeeId: string;
  locationId: string;
  days: number;
  status: string;
}
```

---

# 6. Employee Workflow

### Step 1

Employee opens dashboard.

### Step 2

Current balances are fetched using React Query.

```ts
useQuery({
  queryKey: ["balances"],
  queryFn: getBalances,
});
```

### Step 3

Employee submits a leave request.

### Step 4

An optimistic update immediately reduces the visible balance.

### Step 5

Request is stored with:

```json
{
  "status": "pending"
}
```

### Step 6

Request appears in Request History.

---

# 7. Manager Workflow

### Step 1

Manager opens dashboard.

### Step 2

Pending requests are fetched.

### Step 3

Manager can:

- Approve Request
- Reject Request

### Approval Flow

```text
Pending
   ↓
Approved
```

Balance remains deducted.

### Rejection Flow

```text
Pending
   ↓
Rejected
```

Balance is restored automatically.

---

# 8. Optimistic Update Strategy

The application uses optimistic updates when an employee submits a leave request.

## Benefits

- Faster perceived performance
- Immediate feedback
- Improved user experience

## Process

1. Cache is updated instantly
2. API request is sent
3. If successful:
   - Changes remain

4. If failed:
   - Previous cache is restored

Implementation uses:

```ts
onMutate();
onError();
onSettled();
```

---

# 9. Cache Management Strategy

React Query manages all server state.

## Query Keys

```ts
["balances"]["requests"]["pendingRequests"];
```

## Invalidation

After approval:

```ts
invalidateQueries({
  queryKey: ["balances"],
});

invalidateQueries({
  queryKey: ["requests"],
});

invalidateQueries({
  queryKey: ["pendingRequests"],
});
```

After rejection:

```ts
invalidateQueries({
  queryKey: ["balances"],
});

invalidateQueries({
  queryKey: ["requests"],
});

invalidateQueries({
  queryKey: ["pendingRequests"],
});
```

This ensures all dashboards remain synchronized.

---

# 10. Error Handling

The system handles:

## Invalid Location

```http
400 Bad Request
```

## Insufficient Balance

```http
409 Conflict
```

## Request Not Found

```http
404 Not Found
```

## Failed Mutation

Optimistic changes are rolled back automatically.

---

# 10.1 – HCM Reconciliation Strategy

The application treats HCM as the source of truth for leave balances.

To support reconciliation:

Individual balances can be fetched through an authoritative per-balance endpoint.
Full balance datasets can be fetched through a batch endpoint.
React Query periodically refreshes balance data.
Window focus refetching ensures stale data is refreshed when users return to the application.
Manager actions invalidate relevant cache entries to ensure synchronized state.

This design allows the application to recover from stale data and external balance modifications.

# 10.2 – Simulated HCM Behaviors

The mock HCM layer includes simulated real-world behaviors.

Anniversary Bonus Simulation

A dedicated endpoint allows simulation of balance updates originating outside the application.

Example:

POST /api/hcm/anniversary-bonus

This increases employee balances and demonstrates background balance changes that may occur in real HCM systems.

Conflict Simulation

The request endpoint occasionally returns:

HTTP 409 Conflict

This simulates concurrent balance modifications and validates optimistic rollback behavior.

Silent Failure Simulation

The mock HCM may occasionally return a successful response without persisting the request.

This simulates real-world inconsistencies where backend systems acknowledge requests but fail to apply changes correctly.

The frontend performs reconciliation checks to detect these inconsistencies and notify the user.

# 11 – Storybook

Storybook is used for isolated component development and documentation.

Documented Components:

BalanceTable
RequestForm
RequestHistory
PendingRequests

Target Story States:

Default
Loading
Empty
Optimistic Pending
Optimistic Rollback
HCM Rejected
HCM Silently Wrong
Balance Refreshed Mid Session

Storybook is used to validate both happy-path and edge-case user experiences.

---

# 12. Testing Strategy

The application includes automated testing using Vitest and Playwright.

## Vitest

Used for component-level testing.

Benefits:

- Fast execution
- Reliable assertions
- Easy integration with Storybook

## Playwright

Used through Storybook integration.

Benefits:

- Browser-based testing
- Real rendering validation
- Better confidence in UI behavior

## Test Results

```text
Test Files: 7 Passed
Tests: 12 Passed
```

---

# 13 – Scalability Considerations

The application is designed to support:

Multiple employees
Multiple locations
Additional leave types
Authentication systems
Real API integrations
Persistent databases
Real-time balance synchronization
Background reconciliation workflows
External HCM balance modifications

---

# 14. Alternative Approaches Considered

## Context API

### Pros

- Built into React

### Cons

- Manual cache management
- Manual synchronization

Rejected in favor of React Query.

---

## Redux Toolkit

### Pros

- Powerful global state management

### Cons

- Additional boilerplate
- Unnecessary complexity for server state

Rejected because React Query already solves server-state management effectively.

---

# 15. Assumptions

The following assumptions were made:

- Single employee (EMP001) used for demonstration
- In-memory mock data instead of database persistence
- Authentication is out of scope
- Manager actions are always authorized
- Leave balances are location-specific
- Requests are processed sequentially

---

# 16. Project Setup

## Install Dependencies

```bash
npm install
```

## Run Development Server

```bash
npm run dev
```

## Run Storybook

```bash
npm run storybook
```

## Run Tests

```bash
npx vitest run
```

## Production Build

```bash
npm run build
```

---

# 17. Future Improvements

## Authentication

- Employee Login
- Manager Login

## Real Backend

Replace mock APIs with:

- REST APIs
- GraphQL APIs

## Notifications

- Request Approved
- Request Rejected

## Audit Logs

Track all leave modifications.

## Real-Time Updates

WebSocket integration for instant synchronization.

## Persistent Storage

- PostgreSQL
- MySQL
- MongoDB

---

# 18 – Conclusion

The Time-Off System demonstrates modern frontend engineering practices using Next.js, TypeScript, React Query, Tailwind CSS, Storybook, Vitest, and Playwright.

Key highlights include:

Optimistic UI Updates
Automatic Rollback on Failure
React Query Cache Synchronization
HCM Reconciliation Workflows
Balance Context During Manager Decisions
Simulated Anniversary Bonus Events
Conflict Detection and Recovery
Silent Failure Detection
Leave Approval & Rejection Workflows
Component Documentation with Storybook
Automated Testing with Vitest
Browser Testing with Playwright
Scalable Frontend Architecture

The solution satisfies the assessment requirements while demonstrating resilience against stale data, conflicting updates, and inconsistent backend responses.