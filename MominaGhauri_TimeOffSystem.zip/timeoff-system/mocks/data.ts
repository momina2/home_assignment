export const balances = [
  {
    employeeId: "EMP001",
    locationId: "LHR",
    balance: 10,
    updatedAt: Date.now(),
  },
  {
    employeeId: "EMP001",
    locationId: "KHI",
    balance: 6,
    updatedAt: Date.now(),
  },
];

export const requests: {
  id: string;
  employeeId: string;
  locationId: string;
  days: number;
  status: string;
}[] = [];