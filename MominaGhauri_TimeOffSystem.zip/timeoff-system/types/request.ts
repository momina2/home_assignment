export interface TimeOffRequest {
  id: string;
  employeeId: string;
  locationId: string;
  days: number;
  status: string;
}