export interface Balance {
  employeeId: string;
  locationId: string;
  balance: number;
  updatedAt: number;
}