import { describe, it, expect } from "vitest";

describe("BalanceTable", () => {
  it("should run test successfully", () => {
    expect(true).toBe(true);
  });
});